#version 330 core

in vec3 Normal;
in vec2 Texcoord;
out vec4 outColor;
uniform sampler2D kbdTexture;
uniform sampler2D videoTexture;
uniform sampler2D kbdMaskTexture;
uniform vec4 handsColor;
uniform float handsThreshold;


float grayValue(vec4 c){
	return 0.21*c.r + 0.72*c.g + 0.07*c.b;
}

void main()
{	
	vec4 kbdPixel = texture(kbdTexture,Texcoord);
	vec4 livePixel = texture(videoTexture,Texcoord);
	vec4 maskPixel = texture(kbdMaskTexture, Texcoord);
	float gray = grayValue(livePixel);     		
	float rgbDiff = livePixel.r - livePixel.g;
	float rgbIsSkin = max(sign(rgbDiff - 0.078), 0.0) * max(sign(0.313 - rgbDiff), 0.0) * maskPixel.a;
	outColor = 	mix(kbdPixel, vec4(mix(kbdPixel.rgb,handsColor.rgb*gray*2.0,handsColor.a),kbdPixel.a), step(1.0, rgbIsSkin));
}